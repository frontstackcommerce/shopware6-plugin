<?php

declare(strict_types=1);

namespace Frontstack\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

class Migration20250109101011CreateEntityChangedTable extends MigrationStep
{
    public function getCreationTimestamp(): int
    {
        return 1720610411;
    }

    public function update(Connection $connection): void
    {
        $connection->executeStatement(<<<SQL
            CREATE TABLE `fst_entities_for_update` (
                `id` BINARY(16) NOT NULL,
                `entity` VARCHAR(50) COLLATE utf8mb4_unicode_ci NOT NULL,
                `created_at` DATETIME(3) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        SQL);
    }

    public function updateDestructive(Connection $connection): void
    {
        $connection->executeStatement('DROP TABLE IF EXISTS fst_entities_for_update;');
    }
}
