<?php

declare(strict_types=1);

namespace Frontstack\Controller\Administration;

use Frontstack\Services\Config\ConfigService;
use Frontstack\Services\Onboarding\ShopwareOnboardingService;
use Shopware\Core\Framework\Api\Controller\ApiController;
use Shopware\Core\Framework\Api\Util\AccessKeyHelper;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\System\Integration\IntegrationEntity;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Shopware\Storefront\Framework\Routing\Router;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class AdminCheckController extends ApiController
{
    private string $fstBackendBaseUrl;

    private string $fstAppBaseUrl;

    private const FST_ONBOARDING_ROUTE = '/api/_action/onboarding/shopware/onboard';

    public function __construct(
        private readonly ParameterBagInterface $parameterBag,
        private readonly ConfigService $fstConfigService,
        private readonly Router $router,
    ) {
        $backendUrl = $this->parameterBag->get('frontstack.backend_url');
        if (!is_string($backendUrl)) {
            $backendUrl = 'https://backend.frontstack.dev';
        }
        $appUrl = $this->parameterBag->get('frontstack.app_url');
        if (!is_string($appUrl)) {
            $appUrl = 'https://app.frontstack.dev';
        }
        $this->fstBackendBaseUrl = rtrim($backendUrl, '/');
        $this->fstAppBaseUrl = rtrim($appUrl, '/');
    }

    public function startOnboarding(Request $request): Response
    {
        $onboardingService = $this->container->get(ShopwareOnboardingService::class);
        $redirectWithoutLogin = $this->getRedirectWithoutLogin($request);

        if ($redirectWithoutLogin !== null) {
            return $redirectWithoutLogin;
        }

        $this->refreshAdminCredentials($request);

        $isAlreadyConnected = $onboardingService->isAlreadyConnected();

        if ($isAlreadyConnected) {
            return new Response(
                '<html><body><h1>Already connected</h1><p>You are already connected to Frontstack. Please remove the integration first before starting the onboarding process again.</p></body></html>',
                Response::HTTP_BAD_REQUEST
            );
        }

        $shopwareAdminUrl = $this->router->generate(
            'administration.frontstack.admin-check',
            ['projectId' => '0'],
            UrlGeneratorInterface::ABSOLUTE_URL
        );

        #we need to remove ?=0 as we don't have an projectId yet
        $shopwareAdminUrl = str_replace('/0', '', $shopwareAdminUrl);
        $redirectUrl = $this->fstAppBaseUrl . "/sso/shopware?redirectTo=" . urlencode($shopwareAdminUrl);

        return new RedirectResponse(
            $redirectUrl,
            Response::HTTP_FOUND
        );
    }

    public function createIntegration(Request $request, Context $context): JsonResponse
    {
        $integrationName = 'fst.';
        $integrationRepository = $this->container->get('integration.repository');

        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('label', $integrationName));
        $existingIntegration = $integrationRepository->search($criteria, $context)->first();

        if ($existingIntegration instanceof IntegrationEntity) {
            try {
                $integrationRepository->delete([['id' => $existingIntegration->getId()]], $context);
            } catch (\Exception $e) {
                return new JsonResponse([
                    'error' => 'Failed to delete existing integration: ' . $e->getMessage(),
                ], Response::HTTP_INTERNAL_SERVER_ERROR);
            }
        }

        $accessKey = AccessKeyHelper::generateAccessKey('integration');
        $secretAccessKey = AccessKeyHelper::generateSecretAccessKey();

        $integrationRepository->create([
            [
                'label' => $integrationName,
                'accessKey' => $accessKey,
                'secretAccessKey' => $secretAccessKey,
                'admin' => true,
            ],
        ], $context);

        $integration = [
            'accessKey' => $accessKey,
            'secretAccessKey' => $secretAccessKey,
        ];

        return new JsonResponse($integration);
    }

    public function checkAdminLogin(Request $request): Response
    {
        $authCookie = $request->getSession()->get('fst.adminToken', null);
        $projectId = $request->get('project', null);
        if ($projectId === null) {
            throw new \InvalidArgumentException('Project ID is required');
        }

        #make sure we remeber the token for the frontstack backend
        $token = $request->get('token');
        if ($token) {
            $request->getSession()->set('fst.onboarding-token', $token);
        } else {
            $token = $request->getSession()->get('fst.onboarding-token', null);
            if ($token === null) {
                $shopwareAdminUrl = $this->router->generate(
                    'administration.frontstack.admin-check',
                    ['projectId' => $projectId],
                    UrlGeneratorInterface::ABSOLUTE_URL
                );
                $redirectUrl = $this->fstAppBaseUrl . "/sso/shopware?redirectTo=" . $shopwareAdminUrl;

                return new Response(
                    '<html><body><h1>Login to Frontstack</h1><p>Please login/register to Frontstack to continue the onboarding process.</p><a href="' . $redirectUrl . '">Login to Frontstack</a></body></html>',
                    400
                );
            }
        }

        if (!$authCookie) {
            return new Response(
                '<html><body><h1>Login to your Shopware Administration</h1><p>Please login to your shopware Administration <a href="' . $this->router->generate('administration.index', [], UrlGeneratorInterface::ABSOLUTE_URL) . '">Shopware Administration -></a></p></body></html>',
                400
            );
        }

        $alreadyConnected = $this->container->get(ShopwareOnboardingService::class)->isAlreadyConnected();
        if ($alreadyConnected) {
            return new Response(
                '<html><body><h1>Already connected</h1><p>You are already connected to Frontstack. Please remove the integration first before starting the onboarding process again.</p></body></html>',
                Response::HTTP_BAD_REQUEST
            );
        }

        //renew the token in the session
        $this->refreshAdminCredentials($request);

        $authCookie = $request->getSession()->get('fst.adminToken', $authCookie);
        $authCookie = json_decode($authCookie, true);
        $authCookie = $authCookie['access'];

        $url = $this->router->generate(
            'api.frontstack.create-integration',
            [],
            UrlGeneratorInterface::ABSOLUTE_URL
        );
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $authCookie,
            'Accept: application/json',
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (curl_errno($ch) !== 0) {
            $errorMessage = 'Curl error during integration creation: ' . curl_error($ch);
            curl_close($ch);

            return new JsonResponse([$errorMessage], 500);
        }
        curl_close($ch);

        if (!is_string($response)) {
            return new Response('Error creating integration: No response from server', 500);
        }
        $result = json_decode($response, true);
        if ($httpCode !== Response::HTTP_OK) {
            $responseText = 'Error creating integration Unknown error';
            if ($this->fstConfigService->isDebugEnabled()) {
                $jsonRepsonsePretty = json_decode($response, true);
                $jsonRepsonsePretty = json_encode($jsonRepsonsePretty, JSON_PRETTY_PRINT);
                $responseText .= 'Debug:<br /> code: ' . $httpCode;
                $responseText .= '<br /> Response: <pre>' . $jsonRepsonsePretty . '</pre>';
                $responseText .= '<br /> Request: curl -X POST ' . $url . ' -H "Authorization: Bearer ' . $authCookie . '" -H "Accept: application/json"';
            }

            return new Response(
                $responseText,
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        #and now call the backend from frontstack to kick off everything
        $ingestData = $this->createIntegrationInFrontstack($token, $result['accessKey'], $result['secretAccessKey'], $projectId);

        /** @var SystemConfigService $shopwareconfig */
        $shopwareconfig = $this->container->get(SystemConfigService::class);
        $shopwareconfig->set(ConfigService::INGEST_URL_PRODUCTS_NAME, $ingestData['productIngestUrl']);
        $shopwareconfig->set(ConfigService::INGEST_URL_CATEGORIES_NAME, $ingestData['categoryIngestUrl']);
        $shopwareconfig->set(ConfigService::INGEST_API__KEY_NAME, $ingestData['ingestApiKey']);

        $request->getSession()->remove('fst.adminToken');

        return new Response(
            '<html><body><h1>Onboarding completed</h1><p>Integration created successfully. You can now use the Frontstack features.</p><a href="' . $this->fstAppBaseUrl . '">Frontstack Dashboard</a></body></html>'
        );
    }

    private function refreshAdminCredentials(Request $request): void
    {
        $shopwareAdminToken = $request->cookies->get('bearerAuth', null);
        if ($shopwareAdminToken === null) {
            return;
        }
        $request->getSession()->set('fst.adminToken', $shopwareAdminToken);
    }

    private function getBaseUrl(): string
    {
        /** @phpstan-ignore-next-line */
        return $this->container->getParameter('APP_URL');
    }

    /**
     * @return array{productIngestUrl: string, categoryIngestUrl: string, ingestApiKey: string}
     */
    private function createIntegrationInFrontstack(string $fstJwt, string $accessKey, string $secretKey, string $projectId): array
    {
        $onboardingUrl = $this->fstBackendBaseUrl . self::FST_ONBOARDING_ROUTE . '/' . $projectId;
        $body = json_encode([
            'hostUrl' => self::getBaseUrl(),
            'apiKey' => $accessKey,
            'apiSecret' => $secretKey,
        ]);

        $ch = curl_init($onboardingUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $fstJwt,
            'Content-Type: application/json',
            'Accept: application/json',
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($ch);
        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if (curl_errno($ch) !== 0) {
            throw new \RuntimeException('Curl error during onboarding: ' . curl_error($ch));
        }

        if ((int)$statusCode >= Response::HTTP_MULTIPLE_CHOICES) { #<=300
            throw new \RuntimeException('Error during onboarding: ' . $response);
        }
        if ($response === false || !is_string($response)) {
            throw new \RuntimeException('Error during onboarding: No response from server');
        }
        $ingestdata = json_decode($response, true);

        return ['productIngestUrl' => $ingestdata['productIngestUrl'], 'categoryIngestUrl' => $ingestdata['categoryIngestUrl'], 'ingestApiKey' => $ingestdata['ingestApiKey']];
    }

    private function getAdminCookie(Request $request): ?string
    {
        $auth = $request->cookies->get('bearerAuth', null);
        if ($auth !== null) {
            $auth = (string)$auth;
        }

        return $auth;
    }

    private function getRedirectWithoutLogin(Request $request): ?RedirectResponse
    {
        $adminCookie = $this->getAdminCookie($request);
        if ($adminCookie === null) {
            return new RedirectResponse(
                $this->router->generate(
                    'administration.index',
                    [],
                    UrlGeneratorInterface::ABSOLUTE_URL
                ),
            );
        }

        return null;
    }
}
