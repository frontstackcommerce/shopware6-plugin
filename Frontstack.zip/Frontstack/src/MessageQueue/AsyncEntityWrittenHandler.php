<?php

declare(strict_types=1);

namespace Frontstack\MessageQueue;

use Frontstack\Services\Config\ConfigService;
use Frontstack\Services\HttpClient;
use Frontstack\Services\UrlCleaner;
use Psr\Log\LoggerInterface;
use Symfony\Component\Messenger\Attribute\AsMessageHandler;

#[AsMessageHandler]
class AsyncEntityWrittenHandler
{
    private HttpClient $clientProducts;

    private HttpClient $clientCategories;

    private LoggerInterface $logger;

    public function __construct(ConfigService $configService, LoggerInterface $logger)
    {
        $this->logger = $logger;

        $urlCleaner = new UrlCleaner();

        # remove any trailing fetch/ingest/upsert
        $urlProducts = $urlCleaner->cleanUrl($configService->getProductsUrl());
        $urlCategories = $urlCleaner->cleanUrl($configService->getCategoriesUrl());

        $this->clientProducts = new HttpClient($urlProducts, $configService->getApiKey());
        $this->clientCategories = new HttpClient($urlCategories, $configService->getApiKey());
    }

    public function __invoke(AsyncEntityWrittenMessage $message): void
    {
        try {
            $payload = $message->getIds();

            $intent = $message->getIntent();
            if ($intent !== AsyncEntityWrittenMessage::INTENT_FETCH_LIST) {
                $payload = ['id' => $message->getId()];
            }

            $payloadString = (string)json_encode($payload);

            if ($message->getEntity() === AsyncEntityWrittenMessage::ENTITY_PRODUCT) {
                $this->logger->info(
                    'Notify Frontstack about product changes for ID: ' . implode(', ', $message->getIds()),
                    [
                        'entity' => 'product',
                        'ingestUrl' => $this->clientProducts->getUrl(),
                        'payload' => $payloadString,
                        'intent' => $intent,
                    ]
                );

                $this->clientProducts->post($intent, $payloadString);

                return;
            }

            if ($message->getEntity() === AsyncEntityWrittenMessage::ENTITY_CATEGORY) {
                $this->logger->info(
                    'Notify Frontstack about category changes for ID: ' . implode(', ', $message->getIds()),
                    [
                        'entity' => 'category',
                        'ingestUrl' => $this->clientProducts->getUrl(),
                        'payload' => $payloadString,
                        'intent' => $intent,
                    ]
                );

                $this->clientCategories->post($intent, $payloadString);

                return;
            }

            throw new \Exception('Unknown entity type: ' . $message->getEntity());
        } catch (\Throwable $e) {
            $this->logger->error($e->getMessage());
        }
    }
}
