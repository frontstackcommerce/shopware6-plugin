<?php

declare(strict_types=1);

namespace Frontstack\MessageQueue;

class AsyncEntityWrittenMessage
{
    public const ENTITY_PRODUCT = 'product';
    public const ENTITY_CATEGORY = 'category';
    public const INTENT_FETCH_LIST = 'fetch-list';
    public const INTENT_DELETE = 'delete';

    private string $entity;

    /**
     * @var string[]
     */
    private array $ids;

    private string $intent;

    /**
     * @param string[] $ids
     */
    public function __construct(string $entity, array $ids, string $intent)
    {
        $this->entity = $entity;
        $this->ids = $ids;
        $this->intent = $intent;
    }

    public function getEntity(): string
    {
        return $this->entity;
    }

    /**
     * @return string[]
     */
    public function getIds(): array
    {
        return $this->ids;
    }

    public function getId(): string
    {
        return $this->ids[0];
    }

    public function getIntent(): string
    {
        return $this->intent;
    }
}
