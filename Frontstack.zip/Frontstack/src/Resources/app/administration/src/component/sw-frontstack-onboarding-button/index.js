import template from './sw-frontstack-onboarding-button.html.twig';

/**
 * @package frontstack
 * @version 1.0.0
 */
Shopware.Component.register('frontstack-onboarding-button', {
    template,

    props: {
        value: {
            type: String,
            required: false,
            default: null
        }
    },

    data() {
        return {
            isConfigured: false,
            isLoading: true,
            pluginConfig: null
        };
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.isLoading = true;

            const salesChannelId = this.$route && this.$route.params && this.$route.params.id
                ? this.$route.params.id
                : null;

            if (!this.systemConfigApiService) {
                this.isLoading = false;
                return;
            }

            this.systemConfigApiService.getValues('Frontstack.config', salesChannelId)
                .then(response => {
                    this.pluginConfig = response;
                    this.isConfigured = !!(
                        this.pluginConfig['Frontstack.config.ingestApiKey'] ||
                        this.pluginConfig['Frontstack.config.ingestUrlProducts'] ||
                        this.pluginConfig['Frontstack.config.ingestUrlCategories']
                    );
                })
                .catch(error => {
                    this.isConfigured = false;
                })
                .finally(() => {
                    this.isLoading = false;
                });
        },

        startOnboarding() {
            const adminPath = window.location.origin+window.location.pathname;
            const fullUrl = `${adminPath}/frontstack/start-onboarding`;

            window.open(fullUrl, '_blank');
        }
    },

    inject: ['systemConfigApiService']
});
