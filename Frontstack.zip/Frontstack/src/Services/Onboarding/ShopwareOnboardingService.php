<?php

declare(strict_types=1);

namespace Frontstack\Services\Onboarding;

use Frontstack\Services\Config\ConfigService;

class ShopwareOnboardingService
{
    public function __construct(private ConfigService $frontstackConfigService)
    {
    }

    public function isAlreadyConnected(): bool
    {
        $productIngestUrl = $this->frontstackConfigService->getProductsUrl();
        $categoryIngestUrl = $this->frontstackConfigService->getCategoriesUrl();
        $apiKey = $this->frontstackConfigService->getApiKey();

        if (!empty($productIngestUrl) || !empty($categoryIngestUrl) || !empty($apiKey)) {
            return true;
        }
        return false;
    }

}
