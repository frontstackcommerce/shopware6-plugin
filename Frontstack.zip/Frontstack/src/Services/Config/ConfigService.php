<?php

declare(strict_types=1);

namespace Frontstack\Services\Config;

use Shopware\Core\System\SystemConfig\SystemConfigService;

class ConfigService
{
    private const DEFAULT_LOG_FILE_DAYS = 14;

    private string $apiKey;
    private string $productsUrl;
    private string $categoriesUrl;

    private mixed $debugEnabled;
    private mixed $logFileDays;

    public const INGEST_API__KEY_NAME = 'Frontstack.config.ingestApiKey';
    public const INGEST_URL_PRODUCTS_NAME = 'Frontstack.config.ingestUrlProducts';
    public const INGEST_URL_CATEGORIES_NAME = 'Frontstack.config.ingestUrlCategories';

    public function __construct(SystemConfigService $systemConfigService)
    {
        $this->apiKey = $systemConfigService->getString(self::INGEST_API__KEY_NAME);
        $this->productsUrl = $systemConfigService->getString(self::INGEST_URL_PRODUCTS_NAME);
        $this->categoriesUrl = $systemConfigService->getString(self::INGEST_URL_CATEGORIES_NAME);

        $this->debugEnabled = $systemConfigService->get('Frontstack.config.loggingDebugEnabled');
        $this->logFileDays = $systemConfigService->get('Frontstack.config.loggingFileDays');
    }

    public function getApiKey(): string
    {
        return $this->apiKey;
    }

    public function getProductsUrl(): string
    {
        return $this->productsUrl;
    }

    public function getCategoriesUrl(): string
    {
        return $this->categoriesUrl;
    }

    public function isDebugEnabled(): bool
    {
        if ($this->debugEnabled === null) {
            return false;
        }

        return (bool)$this->debugEnabled;
    }

    public function getLogFileDays(): int
    {
        if ($this->logFileDays === null) {
            return self::DEFAULT_LOG_FILE_DAYS;
        }

        return (int)$this->logFileDays;
    }
}
