<?php

declare(strict_types=1);

namespace Frontstack\Services;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Messenger\MessageBusInterface;

class MessengerBusFactory
{
    private ContainerInterface $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function getMessengerBus(): MessageBusInterface
    {
        if ($this->container->has('messenger.bus.shopware')) {
            /** @var MessageBusInterface $messageBus */
            $messageBus = $this->container->get('messenger.bus.shopware');
        } else {
            /** @var MessageBusInterface $messageBus */
            $messageBus = $this->container->get('messenger.default_bus');
        }

        return $messageBus;
    }
}
