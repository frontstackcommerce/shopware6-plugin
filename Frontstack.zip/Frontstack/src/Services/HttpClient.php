<?php

declare(strict_types=1);

namespace Frontstack\Services;

use Symfony\Component\HttpFoundation\Response;

class HttpClient
{
    private const MAX_SUCCESS_RESPONSE_CODE = 299;
    private const CURL_TIMEOUT_MS = 1500;


    private string $url;


    private string $apiKey;


    public function __construct(string $url, string $apiKey)
    {
        $this->url = $url;
        $this->apiKey = $apiKey;
    }


    public function getUrl(): string
    {
        return $this->url;
    }

    /**
     * @throws \Exception
     */
    public function post(string $intent, string $payload): string
    {
        return $this->sendRequest($intent, $payload);
    }

    /**
     * @throws \Exception
     */
    private function sendRequest(string $intent, string $payload): string
    {
        $curl = curl_init();

        $headers = [
            'Authorization: ' . $this->apiKey,
        ];

        curl_setopt_array(
            $curl,
            [
                CURLOPT_URL => $this->url . '/' . $intent,
                CURLOPT_HEADER => false,
                CURLOPT_SSL_VERIFYPEER => true, // Ensure the certificate is valid
                CURLOPT_SSL_VERIFYHOST => 2, // Validate the CN/SAN against the hostname
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => $payload,
                CURLOPT_HTTPHEADER => $headers,
                CURLOPT_TIMEOUT_MS => self::CURL_TIMEOUT_MS,
            ]
        );

        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $curlError = curl_error($curl);
        curl_close($curl);

        if ($httpCode < Response::HTTP_OK || $httpCode > self::MAX_SUCCESS_RESPONSE_CODE) {
            throw new \Exception('Frontstack Request failed: ' . $this->url . ' Curl Error:' . $curlError . '. Response:' . $response . ' with httpStatusCode: ' . $httpCode);
        }

        return (string)$response;
    }
}
