<?php

declare(strict_types=1);

namespace Frontstack\Services\Logger;

use Frontstack\Services\Config\ConfigService;
use Monolog\Handler\RotatingFileHandler;
use Monolog\Logger;
use Monolog\Processor\IntrospectionProcessor;
use Psr\Log\LoggerInterface;

class FrontstackLoggerFactory
{
    /**
     * this is the channel name that will be
     * displayed in the backend. It must not contain spaces
     */
    public const CHANNEL = 'Frontstack';


    private ConfigService $configService;
    private string $filename;


    public function __construct(ConfigService $configService, string $filename)
    {
        $this->filename = $filename;
        $this->configService = $configService;
    }


    public function createLogger(): LoggerInterface
    {
        # 100 = DEBUG, 200 = INFO
        $minLevel = ($this->configService->isDebugEnabled()) ? 100 : 200;
        $retentionDays = $this->configService->getLogFileDays();

        $fileHandler = new RotatingFileHandler($this->filename, $retentionDays, $minLevel);

        $processors = [];
        $processors[] = new IntrospectionProcessor();

        /** @var callable $processor */
        foreach ($processors as $processor) {
            $fileHandler->pushProcessor($processor);
        }

        return new Logger(self::CHANNEL, [$fileHandler]);
    }
}
