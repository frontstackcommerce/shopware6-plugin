<?php

declare(strict_types=1);

namespace Frontstack\Services;

class UrlCleaner
{
    public function cleanUrl(string $url): string
    {
        # remove trailing fetch, ingest, and upsert
        return (string)preg_replace('/\/(fetch|ingest|upsert)$/', '', $url);
    }
}
