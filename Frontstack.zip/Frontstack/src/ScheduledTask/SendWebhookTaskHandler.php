<?php

declare(strict_types=1);

namespace Frontstack\ScheduledTask;

use Doctrine\DBAL\Connection;
use Frontstack\MessageQueue\AsyncEntityWrittenMessage;
use Frontstack\Services\MessengerBusFactory;
use Psr\Log\LoggerInterface;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\MessageQueue\ScheduledTask\ScheduledTaskEntity;
use Shopware\Core\Framework\MessageQueue\ScheduledTask\ScheduledTaskHandler;
use Shopware\Core\Framework\Uuid\Uuid;
use Symfony\Component\Messenger\Attribute\AsMessageHandler;
use Symfony\Component\Messenger\MessageBusInterface;

/** @phpstan-ignore-next-line */
#[AsMessageHandler(handles: SendWebhookTask::class)]
class SendWebhookTaskHandler extends ScheduledTaskHandler
{
    private const DELETE_BATCH_SIZE = 100;

    private Connection $connection;

    private LoggerInterface $logger;

    private MessageBusInterface $messageBus;

    /**
     * @param EntityRepository<ScheduledTaskEntity>|EntityRepositoryInterface $scheduledTaskRepository
     */
    /** @phpstan-ignore-next-line */
    public function __construct(Connection $connection, LoggerInterface $logger, $scheduledTaskRepository, MessengerBusFactory $messengerBusFactory)
    {
        parent::__construct($scheduledTaskRepository, $logger);

        $this->messageBus = $messengerBusFactory->getMessengerBus();
        $this->connection = $connection;
        $this->logger = $logger;
    }

    public function run(): void
    {
        try {
            $entities = [
                AsyncEntityWrittenMessage::ENTITY_PRODUCT,
                AsyncEntityWrittenMessage::ENTITY_CATEGORY,
            ];

            foreach ($entities as $entityName) {
                $sql = "SELECT lower(hex(id)) FROM fst_entities_for_update where entity = '$entityName'";
                $ids = $this->connection->executeQuery($sql)->fetchFirstColumn();
                if (count($ids) === 0) {
                    $this->logger->debug('No entities found for ' . $entityName . " to send webhook for");
                    continue;
                }

                $this->logger->debug('Dispatch webhook for ' . $entityName . " with " . count($ids) . " ids");
                $message = new AsyncEntityWrittenMessage($entityName, $ids, AsyncEntityWrittenMessage::INTENT_FETCH_LIST);
                $this->messageBus->dispatch($message);

                ### Delete handled entities
                $chunked = array_chunk($ids, self::DELETE_BATCH_SIZE);
                foreach ($chunked as $ids) {
                    $deleteSQL = "DELETE FROM fst_entities_for_update WHERE entity = :entityName AND id IN (:ids)";
                    $idsList = Uuid::fromHexToBytesList($ids);

                    $type = \Doctrine\DBAL\ArrayParameterType::STRING;

                    $this->connection->executeStatement(
                        $deleteSQL,
                        [
                            'entityName' => $entityName,
                            'ids' => $idsList,
                        ],
                        ['ids' => $type]
                    );
                    $this->logger->debug('Deleted ' . count($ids) . " entities for " . $entityName, ['ids' => Uuid::fromBytesToHexList($idsList)]);
                }
            }
        } catch (\Throwable $e) {
            $this->logger->error('Error while sending webhook: ' . $e->getMessage(), ['exception' => $e]);
        }
    }

    public static function getHandledMessages(): iterable
    {
        return [SendWebhookTask::class];
    }
}
