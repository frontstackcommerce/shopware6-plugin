<?php

declare(strict_types=1);

namespace Frontstack\ScheduledTask;

use Shopware\Core\Framework\MessageQueue\ScheduledTask\ScheduledTask;

class SendWebhookTask extends ScheduledTask
{
    private const DEFAULT_INTERVAL = 60;

    public static function getTaskName(): string
    {
        return 'fst.send_webhook_task';
    }

    public static function getDefaultInterval(): int
    {
        return  self::DEFAULT_INTERVAL;
    }


}
