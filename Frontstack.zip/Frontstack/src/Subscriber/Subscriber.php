<?php

declare(strict_types=1);

namespace Frontstack\Subscriber;

use Doctrine\DBAL\Connection;
use Frontstack\MessageQueue\AsyncEntityWrittenMessage;
use Frontstack\Services\MessengerBusFactory;
use Psr\Log\LoggerInterface;
use Shopware\Core\Content\Category\CategoryEvents;
use Shopware\Core\Content\Product\ProductEvents;
use Shopware\Core\Framework\DataAbstractionLayer\Event\EntityDeletedEvent;
use Shopware\Core\Framework\DataAbstractionLayer\Event\EntityWrittenEvent;
use Shopware\Core\Framework\Uuid\Uuid;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Messenger\Exception\ExceptionInterface;
use Symfony\Component\Messenger\MessageBusInterface;

class Subscriber implements EventSubscriberInterface
{
    private LoggerInterface $logger;

    private MessageBusInterface $messageBus;

    private Connection $connection;

    public function __construct(Connection $connection, LoggerInterface $logger, MessengerBusFactory $messengerBusFactory)
    {
        $this->connection = $connection;
        $this->logger = $logger;
        $this->messageBus = $messengerBusFactory->getMessengerBus();
    }

    /**
     * @inheritDoc
     */
    public static function getSubscribedEvents(): array
    {
        return [
            ProductEvents::PRODUCT_WRITTEN_EVENT => 'onProductWritten',
            ProductEvents::PRODUCT_DELETED_EVENT => 'onProductDeleted',
            CategoryEvents::CATEGORY_WRITTEN_EVENT => 'onCategoryWritten',
            CategoryEvents::CATEGORY_DELETED_EVENT => 'onCategoryDeleted',
        ];
    }

    public function onProductWritten(EntityWrittenEvent $event): void
    {
        foreach ($event->getWriteResults() as $writeResult) {
            $payload = $writeResult->getPayload();

            if ($payload === []) {
                return;
            }

            $id = $writeResult->getPayload()['id'];

            $this->logger->debug('product.written: ' . $id);

            $this->queueProduct($id, AsyncEntityWrittenMessage::INTENT_FETCH_LIST);
        }
    }

    public function onProductDeleted(EntityDeletedEvent $event): void
    {
        foreach ($event->getWriteResults() as $writeResult) {
            $payload = $writeResult->getPayload();

            if ($payload === []) {
                return;
            }

            $id = $writeResult->getPayload()['id'];

            $this->logger->debug('product.deleted: ' . $id);

            $this->queueProduct($id, AsyncEntityWrittenMessage::INTENT_DELETE);
        }
    }

    public function onCategoryWritten(EntityWrittenEvent $event): void
    {
        foreach ($event->getWriteResults() as $writeResult) {
            $payload = $writeResult->getPayload();

            if ($payload === []) {
                return;
            }

            $id = $writeResult->getPayload()['id'];

            $this->logger->debug('category.written: ' . $id);

            $this->queueCategory($id, AsyncEntityWrittenMessage::INTENT_FETCH_LIST);
        }
    }

    public function onCategoryDeleted(EntityDeletedEvent $event): void
    {
        foreach ($event->getWriteResults() as $writeResult) {
            $payload = $writeResult->getPayload();

            if ($payload === []) {
                return;
            }

            $id = $writeResult->getPayload()['id'];

            $this->logger->debug('category.deleted: ' . $id);

            $this->queueCategory($id, AsyncEntityWrittenMessage::INTENT_DELETE);
        }
    }

    /**
     * @throws ExceptionInterface
     * @throws \Throwable
     */
    private function queueProduct(string $productId, string $intent): void
    {
        try {
            if ($intent === AsyncEntityWrittenMessage::INTENT_FETCH_LIST) {
                $this->connection->executeStatement(
                    '
                INSERT INTO `fst_entities_for_update` (`id`, `entity`, `created_at`)
                VALUES (:id, :entity, NOW())
                ON DUPLICATE KEY UPDATE `created_at` = NOW()',
                    [
                        'id' => Uuid::fromHexToBytes($productId),
                        'entity' => AsyncEntityWrittenMessage::ENTITY_PRODUCT,
                    ]
                );

                return;
            }

            $message = new AsyncEntityWrittenMessage(AsyncEntityWrittenMessage::ENTITY_PRODUCT, [$productId], $intent);
            $this->messageBus->dispatch($message);
        } catch (\Throwable $e) {
            $this->logger->error($e->getMessage());
            throw $e;
        }
    }

    /**
     * @throws ExceptionInterface
     * @throws \Throwable
     */
    private function queueCategory(string $categoryId, string $intent): void
    {
        try {
            if ($intent === AsyncEntityWrittenMessage::INTENT_FETCH_LIST) {
                $this->connection->executeStatement(
                    '
                INSERT INTO `fst_entities_for_update` (`id`, `entity`, `created_at`)
                VALUES (:id, :entity, NOW())
                ON DUPLICATE KEY UPDATE `created_at` = NOW()',
                    [
                        'id' => Uuid::fromHexToBytes($categoryId),
                        'entity' => AsyncEntityWrittenMessage::ENTITY_CATEGORY,
                    ]
                );

                return;
            }
            $message = new AsyncEntityWrittenMessage(AsyncEntityWrittenMessage::ENTITY_CATEGORY, [$categoryId], $intent);

            $this->messageBus->dispatch($message);
        } catch (\Throwable $e) {
            $this->logger->error($e->getMessage());
            throw $e;
        }
    }
}
